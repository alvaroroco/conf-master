# Py Config Handler

[![PyPI - Version](https://img.shields.io/pypi/v/conf-master.svg)](https://pypi.org/project/conf-master)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/conf-master.svg)](https://pypi.org/project/conf-master)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install conf-master
```

## License

`conf-master` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
